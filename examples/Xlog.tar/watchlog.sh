#!/bin/bash
# It only start the log watching 'mechanism' ;)
# Copyright(C) 2000, KARASZI Istvan, License under GPL version 2 or higher.

/usr/bin/tail -n0 -q -f /var/log/debug /var/log/auth.log|colorize
