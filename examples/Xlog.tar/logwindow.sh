#!/bin/bash
# Simple logwindow under your X
# Copyright(C) 2000, KARASZI Istvan, License under GPL version 2 or higher.

name1="Transparent logwindow";
font="outcast";
script="~/bin/watchlog.sh";

aterm +ls -ut -vb -bw 5 -tr -title "$name1" -n "$name1" -fn "$font" -rv +sb -e "$script" &
